---------------------------------------------------------------
mathexam --- A package for math exam
===============================================================
Released under the LaTeX Project Public License v1.3c or later
See http://www.latex-project.org/lppl.txt
---------------------------------------------------------------
This package is developed when I prepare the midterm exam in the Shanghai Jiao Tong University. It based on the `multicol` package to create two column typesetting, and `eso-pic` package to add the basic infomation, such as the title, the score table, as a background image.

USAGE
---------------------------------------------------------------
Download the zip file and unzip to a local directory, then have a look at the `mathexam-main.pdf`, you can edit and compile it by `latexmk -xelatex -shell-escape mathexam-main.tex`.
